<?php

// => Private can be accessed in $this class only
// - cannot be accessed in child classes
// - cannot be accessed off object instances

// => Protected can be accessed in $this class and in child classes
// - can not be accessed off object instances anywhere

// => Public can be accessed in $this class and in child classes
